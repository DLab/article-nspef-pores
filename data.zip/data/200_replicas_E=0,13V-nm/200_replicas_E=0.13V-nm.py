#!/usr/bin/python3

import os
from math import *


a=1


while a <= 200:

	
	
	print ('gmx grompp -f 50ns_E=0,13_isotropic.mdp -c 200ns_310K.gro -r 200ns_310K.gro -p topol.top -n index.ndx -o 50ns_E=0,13_isotropic_R{:.0f}.tpr -maxwarn 1'.format(a))
	
	
	a=a+1



