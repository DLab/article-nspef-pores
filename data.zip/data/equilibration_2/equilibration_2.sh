source /usr/local/gromacs/bin/GMXRC



gmx grompp -f 200ns_310K.mdp -c step6.6_equilibration.gro -r step6.6_equilibration.gro -p topol.top -n index.ndx -o 200ns_310K.tpr
gmx mdrun -nt 32 -nb gpu -gpu_id 2,3,4,5 -deffnm 200ns_310K -v

