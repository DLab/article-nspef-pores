source /usr/local/gromacs/bin/GMXRC



gmx grompp -f step6.0_minimization.mdp -c step5_input.gro -r step5_input.gro -p topol.top -o step6.0_minimization.tpr
gmx mdrun -nt 16 -nb gpu -gpu_id 0,1 -deffnm  step6.0_minimization -v 

gmx grompp -f step6.3_equilibration.mdp -c step6.2_equilibration.gro -r step6.2_equilibration.gro -p topol.top -n index.ndx -o step6.1_equilibration.tpr
gmx mdrun -nt 16 -nb gpu -gpu_id 0,1 -deffnm step6.1_equilibration -v

gmx grompp -f step6.3_equilibration.mdp -c step6.1_equilibration.gro -r step6.1_equilibration.gro -p topol.top -n index.ndx -o step6.2_equilibration.tpr
gmx mdrun -nt 16 -nb gpu -gpu_id 0,1 -deffnm step6.2_equilibration -v

gmx grompp -f step6.3_equilibration.mdp -c step6.2_equilibration.gro -r step6.2_equilibration.gro -p topol.top -n index.ndx -o step6.3_equilibration.tpr
gmx mdrun -nt 16 -nb gpu -gpu_id 0,1 -deffnm step6.3_equilibration -v

gmx grompp -f step6.4_equilibration.mdp -c step6.3_equilibration.gro -r step6.3_equilibration.gro -p topol.top -n index.ndx -o step6.4_equilibration.tpr
gmx mdrun -nt 16 -nb gpu -gpu_id 0,1 -deffnm step6.4_equilibration -v

gmx grompp -f step6.5_equilibration.mdp -c step6.4_equilibration.gro -r step6.4_equilibration.gro -p topol.top -n index.ndx -o step6.5_equilibration.tpr
gmx mdrun -nt 16 -nb gpu -gpu_id 0,1 -deffnm step6.5_equilibration -v

gmx grompp -f step6.6_equilibration.mdp -c step6.5_equilibration.gro -r step6.5_equilibration.gro -p topol.top -n index.ndx -o step6.6_equilibration.tpr
gmx mdrun -nt 16 -nb gpu -gpu_id 0,1 -deffnm step6.6_equilibration -v
