source /usr/local/gromacs/bin/GMXRC


gmx grompp -f 50ns_E=0,12_isotropic.mdp -c 200ns_310K.gro -r 200ns_310K.gro -p topol.top -n index.ndx -o 50ns_E=0,12_isotropic_R1.tpr -maxwarn 1
gmx grompp -f 50ns_E=0,12_isotropic.mdp -c 200ns_310K.gro -r 200ns_310K.gro -p topol.top -n index.ndx -o 50ns_E=0,12_isotropic_R2.tpr -maxwarn 1
gmx grompp -f 50ns_E=0,12_isotropic.mdp -c 200ns_310K.gro -r 200ns_310K.gro -p topol.top -n index.ndx -o 50ns_E=0,12_isotropic_R3.tpr -maxwarn 1
gmx grompp -f 50ns_E=0,12_isotropic.mdp -c 200ns_310K.gro -r 200ns_310K.gro -p topol.top -n index.ndx -o 50ns_E=0,12_isotropic_R4.tpr -maxwarn 1
gmx grompp -f 50ns_E=0,12_isotropic.mdp -c 200ns_310K.gro -r 200ns_310K.gro -p topol.top -n index.ndx -o 50ns_E=0,12_isotropic_R5.tpr -maxwarn 1 
gmx grompp -f 50ns_E=0,12_isotropic.mdp -c 200ns_310K.gro -r 200ns_310K.gro -p topol.top -n index.ndx -o 50ns_E=0,12_isotropic_R6.tpr -maxwarn 1
gmx grompp -f 50ns_E=0,12_isotropic.mdp -c 200ns_310K.gro -r 200ns_310K.gro -p topol.top -n index.ndx -o 50ns_E=0,12_isotropic_R7.tpr -maxwarn 1
gmx grompp -f 50ns_E=0,12_isotropic.mdp -c 200ns_310K.gro -r 200ns_310K.gro -p topol.top -n index.ndx -o 50ns_E=0,12_isotropic_R8.tpr -maxwarn 1
